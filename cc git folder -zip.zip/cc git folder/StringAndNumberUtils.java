public class StringAndNumberUtils {

    // Check palindrome
    public static boolean isPalindrome(String str) {
        String reversed = new StringBuilder(str).reverse().toString();
        return str.equalsIgnoreCase(reversed);
    }

    // Reverse a string
    public static String reverseString(String str) {
        return new StringBuilder(str).reverse().toString();
    }

    // Print all digits in a string
    public static void printDigits(String str) {
        for (char ch : str.toCharArray()) {
            if (Character.isDigit(ch)) {
                System.out.print(ch + " ");
            }
        }
        System.out.println();
    }

    // Print all characters in a string
    public static void printChars(String str) {
        for (char ch : str.toCharArray()) {
            System.out.print(ch + " ");
        }
        System.out.println();
    }

    // Convert characters to opposite case
    public static String convertToOppositeCase(String str) {
        StringBuilder result = new StringBuilder();
        for (char ch : str.toCharArray()) {
            if (Character.isUpperCase(ch)) {
                result.append(Character.toLowerCase(ch));
            } else if (Character.isLowerCase(ch)) {
                result.append(Character.toUpperCase(ch));
            } else {
                result.append(ch);
            }
        }
        return result.toString();
    }

    // Encode a string (simple Caesar cipher with shift of 3)
    public static String encodeString(String str) {
        StringBuilder encoded = new StringBuilder();
        for (char ch : str.toCharArray()) {
            if (Character.isLetter(ch)) {
                char base = Character.isLowerCase(ch) ? 'a' : 'A';
                encoded.append((char) ((ch - base + 3) % 26 + base));
            } else {
                encoded.append(ch);
            }
        }
        return encoded.toString();
    }

    public static void main(String[] args) {
        String testString = "Abc123cba";
        
        // Example usage
        System.out.println("Is Palindrome: " + isPalindrome(testString));
        System.out.println("Reversed String: " + reverseString(testString));
        System.out.print("Digits: ");
        printDigits(testString);
        System.out.print("Characters: ");
        printChars(testString);
        System.out.println("Opposite Case: " + convertToOppositeCase(testString));
        System.out.println("Encoded String: " + encodeString(testString));
    }
}
