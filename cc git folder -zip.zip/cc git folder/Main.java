package strs;

import java.util.*;



public class Main {
	
	static void countWord(String CW) {
		int count=0;
		String[] words=CW.split(" ");
		System.out.println(words.length);
		
//		for(int i=0;i<CW.length();i++)
//		{
//			char ch=CW.charAt(i);
//			
//			if(ch==' ') {
//				count+=1;
//			}
//		}
//		System.out.println(count+1);
	}
	
	static void specificCount(String str,String sWord) {
		int count=0;
		String[] words = str.split(" ");
		for(String word:words) {
			if(word.equals(sWord)) {
				count+=1;
			}
		}
		
		System.out.println(count);
		
//		String temp="";
//		for(int i=0;i<SW.length();i++)
//		{
//			
//			char ch=SW.charAt(i);
//			if(ch==' ') {
//				if(temp.equals(W)) {
//					count+=1;
//				}
//				temp="";
//			}
//			else {
//				temp+=ch;
//			}
//			
//		}
//		System.out.println(count);
		
		
		
	}
	
	static void wordLength(String str) {
		
		System.out.println(str.length());
		
//		int count=0;
//		for(int i=0;i<str.length();i++) {
//			
//			char ch=str.charAt(i);
//			count+=1;
//		}
//		
//		System.out.println(count);
	}
	
	static void specificChar(String str,String specChar) {
		int count=0;
		String[] word=str.split(" ");
		for(String i:word) {
			if(i.startsWith(specChar)) {
				count+=1;
			}
		}
		System.out.println(count);

	}
	
	
	
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the string for counting Words: ");
		String CW=sc.nextLine();
		
		countWord(CW);
		
		System.out.println("Enter string to Count Specific word: ");
		String SW=sc.nextLine();
		
		System.out.println("Enter Specific word: ");
		String W=sc.nextLine();
		
		specificCount(SW,W);
		

		System.out.println("Enter word to count its length: ");
		String WL=sc.nextLine();
		
		wordLength(WL);
		
		System.out.println("Starting with specific: ");
		String specific=sc.nextLine();
		
		System.out.println("specific char: ");
		String specChar=sc.nextLine();
		
		specificChar(specific,specChar);
		
		
		
		
	}

}

